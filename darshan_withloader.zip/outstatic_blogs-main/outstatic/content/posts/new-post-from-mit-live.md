---
title: 'new post from mit live'
status: 'published'
author:
  name: 'newadsas'
  picture: '/images/product-10-Y3Nz.jpg'
slug: 'new-post-from-mit-live'
description: 'mifnsdbfbnas d fsdhbj fdnbfd sd'
coverImage: '/images/slide-06-MyMz.jpg'
publishedAt: '2023-08-08T13:41:29.361Z'
---

new post from mit livenew post from mit livenew post from mit livenew post from mit live

