import "outstatic/outstatic.css";
import { Outstatic, OstSSP } from "outstatic";

export default Outstatic;

export const getServerSideProps = OstSSP;
