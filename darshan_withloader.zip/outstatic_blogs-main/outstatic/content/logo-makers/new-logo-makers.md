---
title: 'new logo makers'
status: 'published'
author:
  name: 'logoman'
  picture: 'https://avatars.githubusercontent.com/u/141731814?v=4'
slug: 'new-logo-makers'
description: 'new ms'
coverImage: '/images/designs-ai-768x402-UwOD.png'
publishedAt: '2023-08-08T12:37:13.541Z'
---

new logo makers

