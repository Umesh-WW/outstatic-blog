import { OutstaticApi } from "outstatic";

export default OutstaticApi;
